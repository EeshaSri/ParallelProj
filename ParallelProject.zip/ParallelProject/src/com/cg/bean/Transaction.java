package com.cg.bean;

public class Transaction {
	
	private int accountNumber;
	private double credit;
	private double debit;
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getCredit() {
		return credit;
	}
	public void setCredit(double credit) {
		this.credit = credit;
	}
	public double getDebit() {
		return debit;
	}
	public void setDebit(double debit) {
		this.debit = debit;
	}
	
	@Override
	public String toString() {
		return "Transaction [accountNumber=" + accountNumber + ", credit=" + credit + ", debit=" + debit + "]";
	}
	
	

}
