package com.cg.dao;

import java.util.ArrayList;
import java.util.List;
import com.cg.bean.Account;
import com.cg.bean.Transaction;

public class AccountData {
	
	public List<Account> accountList=new ArrayList<>();
	List<Double> depAmount=new ArrayList<>();
	List<Double> wdAmount=new ArrayList<>();
	List<Transaction> transactionList=new ArrayList<>();


	@Override
	public String toString() {												
		return "AccountData [accountList=" + accountList + "]";
	}
	
	

	public void storeData(Account account) {	
		
		accountList.add(account);
		
	}
	
	
	public List<Account> returnStoreData(){		
	
		return accountList;
	}
	
	
	public void storeDepositData(double depositAmmount) {
		depAmount.add(depositAmmount);
	}
	
	
	public List<Double> returnDepositData() {
		return depAmount;
	}
	
	public void storeWithdrawData(double withdrawAmmount) {
		wdAmount.add(withdrawAmmount);
	}
	
	
	public List<Double> returnWithDrawData() {
		return wdAmount; 
	}
	
	public void storeTransactions(Transaction transaction) {
		transactionList.add(transaction);
	}
	
	public List<Transaction> returnTransactions(){
		return transactionList;
	}

	
}
