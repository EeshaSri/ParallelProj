package com.cg.service;


import java.util.List;
import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.dao.AccountData;
import com.cg.ui.FrontEnd;

public class AccountService {
	
	FrontEnd frontEnd=new FrontEnd();
	AccountData accountData=new AccountData();
	

	public void createAccount(Account account) {
		accountData.storeData(account);
		
	}
	public double showBalance(int accountNumber) {
		List<Account> accountList1=accountData.returnStoreData();
		for(Account account:accountList1) {
			if(accountNumber==account.getAccountNumber()) {
				return account.getBalance();
			}
		}
		return 0;
	}
	
	
	public double depositAmount(int accountNumber1,double depositAmmount) {
		double a=0;
		List<Account> accountList1=accountData.returnStoreData();
		List<Transaction> transList1=accountData.returnTransactions();
		Transaction trans=new Transaction();
		for(Account account:accountList1) {
			if(accountNumber1==account.getAccountNumber()) {
				a=account.getBalance()+depositAmmount;
				account.setBalance(a);
				return a;
			}
		}
		return 0;
	}
	
	public double withdrawAmount(int accountNumber2,double withdrawAmmount) {
		double b=0;
		List<Account> accountList1=accountData.returnStoreData();
		List<Transaction> transList1=accountData.returnTransactions();
		for(Account account:accountList1) {
			if(accountNumber2==account.getAccountNumber()) {
				b=account.getBalance()-withdrawAmmount;
				account.setBalance(b);
				return b;
			}
		}
		
		return 0;
	}
	
	public void tranferAccount(int accountNumber3,int accountNumber4,double transferAmmount){
		double c=0;
		double d=0;
		List<Account> accountList1=accountData.returnStoreData();
		List<Transaction> transList1=accountData.returnTransactions();
		for(Account account:accountList1) {
			if(accountNumber3==account.getAccountNumber()) {
				Transaction trans=new Transaction();
				trans.setDebit(transferAmmount);				
				c=account.getBalance()-transferAmmount;
				account.setBalance(c);
				//System.out.println(trans.getDebit()+"debit");
			}
		}
		for(Account account:accountList1) {
			if(accountNumber4==account.getAccountNumber()) {
				Transaction trans=new Transaction();
				trans.setDebit(transferAmmount);	
				trans.setCredit(transferAmmount);
				d=account.getBalance()+transferAmmount;
				account.setBalance(d);
				//System.out.println(trans.getCredit()+"cred");
			}
		}
	}
	
	public List<Transaction> showTransactions(int accountNumber5){
		List<Transaction> transList1=accountData.returnTransactions();
		for(Transaction trans :transList1) {
			if(accountNumber5==trans.getAccountNumber()) {
				return transList1;
			}
		}
		return transList1;
	}
			
}
