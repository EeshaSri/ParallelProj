package com.cg.ui;

public class AccountAccess {
	
	public static void main(String args[]) {
		
		FrontEnd frontEnd=new FrontEnd();
		
			frontEnd.display();
		
	}

}
