package com.cg.ui;

import java.util.Scanner;
import com.cg.bean.Account;
import com.cg.service.AccountService;

public class FrontEnd {
	
	
	public void display() {

		Scanner scanner=new Scanner(System.in);
		
		AccountService accountService=new AccountService();
		
		
		while(true) {
			
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit Amount");
		System.out.println("4.Withdraw Amount");
		System.out.println("5.Transfer Cash");
		System.out.println("6.Show Transactions");
		System.out.println("7.Exit");
		System.out.println("Enter your choice");
		
		switch(scanner.nextInt()) {
		
		case 1:
				Account account=new Account();
				System.out.println("Enter your AccountId");
				account.setAccountNumber(scanner.nextInt());
				System.out.println("Enter your name");
				account.setName(scanner.next());
				System.out.println("Enter your Amount");
				account.setBalance(scanner.nextDouble());
				System.out.println("your account details are "+account);
				accountService.createAccount(account);
				break;
			
		case 2:System.out.println("enter your AccountId");
				int accountNumber=scanner.nextInt();
				if(accountService.showBalance(accountNumber)==0) {
					System.out.println("Invalid Account Number. Please enter the correct value");
				}
				else {
					System.out.println(accountService.showBalance(accountNumber));
				}
				break;
			
		case 3:System.out.println("Enter your Account Id");
				int accountNumber1=scanner.nextInt();
				System.out.println("Enter your deposit amount");
				double depositAmmount=scanner.nextDouble();
				//if(accountService.depositAmount(accountNumber1,depositAmmount)==0) {
					//System.out.println("Invalid Account Number. Please enter the correct value");
				//}
				//else 
				//{
					System.out.println(accountService.depositAmount(accountNumber1,depositAmmount));
				//}
				break;
			
			
		case 4:System.out.println("Enter your Account Id");
				int accountNumber2=scanner.nextInt();
				System.out.println("Enter your withdraw amount");
				double withdrawAmmount=scanner.nextDouble();
				double withDrawAmmount1=accountService.withdrawAmount(accountNumber2,withdrawAmmount);
				//if(wda==0) {
				//	System.out.println("Invalid Account Number. Please enter the correct value");
				//}
				//else {
					
					System.out.println(withDrawAmmount1);
				//}
				break;
		
			
		case 5:System.out.println("Enter your Account Id from which you want to tranfer the amount");
				int accountNumber3=scanner.nextInt();
				System.out.println("Enter the Account Id in which you want to transfer the amount");
				int accountNumber4=scanner.nextInt();
				System.out.println("enter the amount you want to transfer");
				double transferAmmount=scanner.nextDouble();
				accountService.tranferAccount(accountNumber3,accountNumber4,transferAmmount);
				System.out.println("amount tranfered");
			break;
			
		case 6:System.out.println("Enter Account Id");
				int accountNumber5=scanner.nextInt();
				accountService.showTransactions(accountNumber5);
			break;
			
		case 7:scanner.close();
			   System.out.println("Thank You. Visit Again.");
			   System.exit(0);
			  
		}
		
		}
	}

}
